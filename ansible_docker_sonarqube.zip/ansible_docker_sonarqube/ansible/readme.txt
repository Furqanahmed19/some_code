FIrst define the inventory file with postgrees and sonar qube dirrently

ansible-playbook -i inventory.ini -l sonar playbooks/sonar.yml
ansible-playbook -i inventory.ini -l postgree playbooks/postgre.yml


All variable on variable folder
